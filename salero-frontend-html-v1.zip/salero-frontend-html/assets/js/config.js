const SALERO_CONFIG = {
  apiBase: 'https://cms.webagencia360.com/wp-json/wp/v2',
  contactUrl: '/hablamos/',
  whatsappUrl: 'https://wa.me/34665688916?text=Hola%2C%20quiero%20hacer%20una%20cata%20digital%20con%20Salero%20Digital.',
  endpoints: { pages:'pages', posts:'posts', menus:'menus', servicios:'servicios', sectores:'sectores', casos:'casos-exito' }
};
